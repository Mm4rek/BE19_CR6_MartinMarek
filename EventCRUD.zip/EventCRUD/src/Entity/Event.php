<?php

// src/Entity/Event.php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\EventRepository")
 */
class Event
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventName;

    /**
     * @ORM\Column(type="datetime")
     */
    private $eventDateTime;

    /**
     * @ORM\Column(type="text")
     */
    private $eventDescription;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventImage;

    /**
     * @ORM\Column(type="integer")
     */
    private $eventCapacity;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $contactEmail;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $contactPhone;

    /**
     * @ORM\Column(type="text")
     */
    private $eventAddress;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventUrl;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $eventType;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEventName(): ?string
    {
        return $this->eventName;
    }

    public function setEventName(string $eventName): self
    {
        $this->eventName = $eventName;

        return $this;
    }

    public function getEventDateTime(): ?\DateTimeInterface
    {
        return $this->eventDateTime;
    }

    public function setEventDateTime(\DateTimeInterface $eventDateTime): self
    {
        $this->eventDateTime = $eventDateTime;

        return $this;
    }

    public function getEventDescription(): ?string
    {
        return $this->eventDescription;
    }

    public function setEventDescription(string $eventDescription): self
    {
        $this->eventDescription = $eventDescription;

        return $this;
    }

    public function getEventImage(): ?string
    {
        return $this->eventImage;
    }

    public function setEventImage(string $eventImage): self
    {
        $this->eventImage = $eventImage;

        return $this;
    }

    public function getEventCapacity(): ?int
    {
        return $this->eventCapacity;
    }

    public function setEventCapacity(int $eventCapacity): self
    {
        $this->eventCapacity = $eventCapacity;

        return $this;
    }

    public function getContactEmail(): ?string
    {
        return $this->contactEmail;
    }

    public function setContactEmail(string $contactEmail): self
    {
        $this->contactEmail = $contactEmail;

        return $this;
    }

    public function getContactPhone(): ?string
    {
        return $this->contactPhone;
    }

    public function setContactPhone(string $contactPhone): self
    {
        $this->contactPhone = $contactPhone;

        return $this;
    }

    public function getEventAddress(): ?string
    {
        return $this->eventAddress;
    }

    public function setEventAddress(string $eventAddress): self
    {
        $this->eventAddress = $eventAddress;

        return $this;
    }

    public function getEventUrl(): ?string
    {
        return $this->eventUrl;
    }

    public function setEventUrl(string $eventUrl): self
    {
        $this->eventUrl = $eventUrl;

        return $this;
    }

    public function getEventType(): ?string
    {
        return $this->eventType;
    }

    public function setEventType(string $eventType): self
    {
        $this->eventType = $eventType;

        return $this;
    }
}
