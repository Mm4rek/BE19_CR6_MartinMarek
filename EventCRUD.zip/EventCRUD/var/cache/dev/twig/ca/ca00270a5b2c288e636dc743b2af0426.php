<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* event/filter.html.twig */
class __TwigTemplate_ec42ce02a8b291ec4ea3822583a82988 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "event/filter.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "event/filter.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["eventType"]) || array_key_exists("eventType", $context) ? $context["eventType"] : (function () { throw new RuntimeError('Variable "eventType" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "Events";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"container\">
        <div class=\"text-center mb-4\">
            <h1>";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["eventType"]) || array_key_exists("eventType", $context) ? $context["eventType"] : (function () { throw new RuntimeError('Variable "eventType" does not exist.', 8, $this->source); })()), "html", null, true);
        echo " Events</h1>
        </div>
        <div class=\"row\">
            ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["events"]) || array_key_exists("events", $context) ? $context["events"] : (function () { throw new RuntimeError('Variable "events" does not exist.', 11, $this->source); })()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["event"]) {
            // line 12
            echo "                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100\">
                        <img src=\"";
            // line 14
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventImage", [], "any", false, false, false, 14), "html", null, true);
            echo "\" class=\"card-img-top\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventName", [], "any", false, false, false, 14), "html", null, true);
            echo "\"
                        style=\"width: 100%; height: 250px;\">
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">";
            // line 17
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventName", [], "any", false, false, false, 17), "html", null, true);
            echo "</h5>
                            <p class=\"card-text\">";
            // line 18
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["event"], "eventDescription", [], "any", false, false, false, 18), "html", null, true);
            echo "</p>
                        </div>
                        <div class=\"card-footer d-flex justify-content-between\">
                            <a href=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_event_show", ["id" => twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 21)]), "html", null, true);
            echo "\" class=\"btn btn-primary\">Show Details</a>
                            <div>
                                <a href=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_event_edit", ["id" => twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 23)]), "html", null, true);
            echo "\" class=\"btn btn-secondary\">Edit</a>
                                <form method=\"post\" action=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_event_delete", ["id" => twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 24)]), "html", null, true);
            echo "\" onsubmit=\"return confirm('Are you sure you want to delete this event?')\">
                                    <input type=\"hidden\" name=\"_token\" value=\"";
            // line 25
            echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken(("delete" . twig_get_attribute($this->env, $this->source, $context["event"], "id", [], "any", false, false, false, 25))), "html", null, true);
            echo "\">
                                    <button type=\"submit\" class=\"btn btn-danger\">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 33
            echo "                <div class=\"col\">
                    <p>No records found</p>
                </div>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['event'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "        </div>
    </div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "event/filter.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 37,  137 => 33,  124 => 25,  120 => 24,  116 => 23,  111 => 21,  105 => 18,  101 => 17,  93 => 14,  89 => 12,  84 => 11,  78 => 8,  74 => 6,  67 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}{{ eventType }}Events{% endblock %}

{% block body %}
    <div class=\"container\">
        <div class=\"text-center mb-4\">
            <h1>{{ eventType }} Events</h1>
        </div>
        <div class=\"row\">
            {% for event in events %}
                <div class=\"col-md-4 mb-4\">
                    <div class=\"card h-100\">
                        <img src=\"{{ event.eventImage }}\" class=\"card-img-top\" alt=\"{{ event.eventName }}\"
                        style=\"width: 100%; height: 250px;\">
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">{{ event.eventName }}</h5>
                            <p class=\"card-text\">{{ event.eventDescription }}</p>
                        </div>
                        <div class=\"card-footer d-flex justify-content-between\">
                            <a href=\"{{ path('app_event_show', {'id': event.id}) }}\" class=\"btn btn-primary\">Show Details</a>
                            <div>
                                <a href=\"{{ path('app_event_edit', {'id': event.id}) }}\" class=\"btn btn-secondary\">Edit</a>
                                <form method=\"post\" action=\"{{ path('app_event_delete', {'id': event.id}) }}\" onsubmit=\"return confirm('Are you sure you want to delete this event?')\">
                                    <input type=\"hidden\" name=\"_token\" value=\"{{ csrf_token('delete' ~ event.id) }}\">
                                    <button type=\"submit\" class=\"btn btn-danger\">Delete</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            {% else %}
                <div class=\"col\">
                    <p>No records found</p>
                </div>
            {% endfor %}
        </div>
    </div>
{% endblock %}
", "event/filter.html.twig", "C:\\Users\\marti\\Desktop\\Codereview6\\EventCRUD\\templates\\event\\filter.html.twig");
    }
}
